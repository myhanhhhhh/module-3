package model;

public class BaiHoc {
    private int id;
    private String title;
    private String link;
    private int styleId;

    public BaiHoc() {
    }

    public BaiHoc(String title, String link, int styleId) {
        this.title = title;
        this.link = link;
        this.styleId = styleId;
    }

    public BaiHoc(int id, String title, String link, int styleId) {
        this.id = id;
        this.title = title;
        this.link = link;
        this.styleId = styleId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public int getStyleId() {
        return styleId;
    }

    public void setStyleId(int styleId) {
        this.styleId = styleId;
    }
}
