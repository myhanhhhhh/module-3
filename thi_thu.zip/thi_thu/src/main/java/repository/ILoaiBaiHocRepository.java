package repository;

import model.LoaiBaiHoc;

import java.util.List;

public interface ILoaiBaiHocRepository {
    List<LoaiBaiHoc> showListStyle();
}
