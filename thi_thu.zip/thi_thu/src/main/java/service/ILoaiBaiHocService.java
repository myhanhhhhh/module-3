package service;

import model.LoaiBaiHoc;

import java.util.List;

public interface ILoaiBaiHocService {
    List<LoaiBaiHoc> showListStyle();
}
